create database bd_escola;
use bd_escola;

Create table Escola (
id_esc int primary key auto_increment,
nome_fantasia_esc varchar (250) not null,
razao_social_esc varchar (250) not null,
cnpj_esc varchar (100) not null,
insc_estadul_esc varchar (250) not null,
tipo_esc varchar (50) not null,
data_criacao_esc date not null,
responsavel_esc varchar (300) not null,
responsavel_telefone_esc varchar (300) not null,
email_esc varchar (300) not null,
telefone_esc varchar (100) not null,
rua_esc varchar (300) not null,
numero_esc varchar (50) not null,
bairro_esc varchar (100),
cep_esc varchar (300) not null,
cidade_esc varchar (300) not null,
estado_esc varchar (300) not null
);
insert into Escola values(null, '28 de Novembro', 'E.E.E.F.M. 28 de Novembro', '98.657.649/0001-84', '11017775', 'escola', '1990-11-28', 'João', '(69) 3461-6168', 'escola28@seduc.ro.gov.br', '(69) 97587-3016', 'Rua Olavo Bilac', '887', 'União', '76920000', 'Ouro Preto do Oeste', 'Rondônia'); 

select*from Escola